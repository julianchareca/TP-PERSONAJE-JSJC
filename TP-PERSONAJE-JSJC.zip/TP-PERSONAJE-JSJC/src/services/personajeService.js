import sql from 'mssql'
import config from "../db.js";

export default class PersonajeService {
    Get = async (top, orderField, sortOrder) =>{
        let returnEntity = null;
        try{
        let pool = await sql.connect(config);
        let result = await pool.request()
        .query('SELECT Imagen, Nombre, Id FROM Personajes');
        returnEntity = result.recordset;
        }
        catch (error){
            console.log(error)
        }
        return returnEntity;
    }
}