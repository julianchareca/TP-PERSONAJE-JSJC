import sql from 'mssql'
import config from "../db.js";

/*
class Personaje{
    idPersonaje;
    imagen;
    nombre;
    edad;
    peso;
    historia;
}
*/

export default class PersonajeService {
    Get = async () =>{
        let returnEntity = null;
        try{
        let pool = await sql.connect(config);
        let result = await pool.request()
        .query('SELECT * FROM Personajes');
        returnEntity = result.recordset;
        }
        catch (error){
            console.log(error)
        }
        return returnEntity;
    }
    Create = async (personaje) =>{
        const conn = await sql.connect(config);
        const results = await conn.request()
        .input("pNombre", personaje.nombre)
        .input("pImagen", personaje.imagen)
        .input("pEdad", personaje.edad)
        .input("pPeso", personaje.peso)
        .input("pHistoria", personaje.historia)
        .query('INSERT INTO Personajes (Nombre, Imagen, Edad, Peso, Historia) VALUES (@pNombre, @pImagen, @pEdad, @pPeso, @pHistoria)');
        console.log(results)
        return results;
    }
    Update = async (personaje, id) =>{
        const conn = await sql.connect(config);
        const results = await conn.request()
        .input('pId', sql.Int, id)
        .input('pNombre', sql.VarChar, personaje.nombre)
        .input('pImagen', sql.VarChar, personaje.imagen)
        .input('pEdad', sql.Int, personaje.edad)
        .input('pPeso', sql.Int, personaje.peso)
        .input('pHistoria', sql.VarChar, personaje.historia)
        .query('UPDATE Personajes SET Nombre = @pNombre, Imagen = @pImagen, Edad = @pEdad, Peso = @pPeso, Historia = @pHistoria WHERE IdPersonaje = @pId');
        return results;
    }
    Delete = async (id) =>{
        let rowsAffected = 0;
        try{
        let pool = await sql.connect(config);
        let result = await pool.request()
        .input('pId', sql.Int, id)
        .query('Delete FROM Personajes WHERE IdPersonaje = @pId');
        rowsAffected = result.rowsAffected;
        }
        catch (error){
            console.log(error)
        }
        return rowsAffected;
    }
}