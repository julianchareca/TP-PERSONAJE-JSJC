import sql from 'mssql'
import config from "../db.js";

/*
class Personaje{
    idPersonaje;
    imagen;
    nombre;
    edad;
    peso;
    historia;
}
*/
export default class PersonajeService {
    Get = async () =>{
        let returnEntity = null;
        try{
        let pool = await sql.connect(config);
        let result = await pool.request()
        .query('SELECT * FROM Personajes');
        returnEntity = result.recordset;
        }
        catch (error){
            console.log(error)
        }
        return returnEntity;
    }
    Create = async (personaje) =>{
        const connection = await sql.connect(config)
        const results = await connection.request()
            .input("pNombre", sql.VarChar, personaje.Nombre)
            .input("pHistoria", sql.VarChar, personaje.Historia)
            .input("pPeso", sql.Float, personaje.Peso)
            .input("pEdad", sql.Int, personaje.Edad)
            .input("pImagen", sql.VarChar, personaje.Imagen)
            .query('INSERT INTO Personajes (Nombre, Historia, Peso, Edad, Imagen) VALUES (@pNombre, @pHistoria, @pPeso, @pEdad, @pImagen)')
        console.log(results)
    }
    Update = async (personaje, id) =>{
        const conn = await sql.connect(config);
        const results = await conn.request()
        .input('pId', sql.Int, id)
        .input('pNombre', sql.VarChar, personaje.nombre)
        .input('pImagen', sql.VarChar, personaje.imagen)
        .input('pEdad', sql.Int, personaje.edad)
        .input('pPeso', sql.Int, personaje.peso)
        .input('pHistoria', sql.VarChar, personaje.historia)
        .query('UPDATE Personajes SET Nombre = @pNombre, Imagen = @pImagen, Edad = @pEdad, Peso = @pPeso, Historia = @pHistoria WHERE IdPersonaje = @pId');
        return results;
    }
    Delete = async (id) =>{
        const conn = await sql.connect(config)
        const results = await conn.request()
        .input('pId', sql.Int, id)
        .query('DELETE FROM PersPeli WHERE fk_IdPers = @pId DELETE FROM Personaje WHERE Id = @pId');
        console.log(results)
    }
}
