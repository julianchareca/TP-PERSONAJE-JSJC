import sql from 'mssql'
import config from "../db.js";

/*
class PeliculaOSerie{
    id;
    imagen;
    titulo;
    fechaDeCreacion;
    calificacion;
}
*/

export default class PeliOSerieService {
    Get = async () =>{
    }

    Create = async (peliOSerie) =>{
        const results = await connection.request()
            .input("pImagen", sql.VarChar, peliOSerie.Imagen)
            .input("pTitulo", sql.VarChar, peliOSerie.Titulo)
            .input("pFechaDeCreacion", sql.Date, peliOSerie.FechaDeCreacion)
            .input("pCalificacion", sql.Int, peliOSerie.Calificacion)
            .query('INSERT INTO PeliculasOSeries (Imagen, Titulo, FechaDeCreacion, Calificacion) VALUES (@pImagen, @pTitulo, @pFechaDeCreacion, @pCalificacion)')
        console.log(results)
    }
}