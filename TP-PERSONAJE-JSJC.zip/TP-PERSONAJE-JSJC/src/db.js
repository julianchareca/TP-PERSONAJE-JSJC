const config = {
    user:       'Personajes',
    password:   'Personajes',
    server:     'A-PHZ2-CIDI-028',
    database:   'PersonajesTP',
    options: {
        trustServerCertificate:     true,
        trustedConnection:          true,
    }
}
export default config