const config = {
    user:       'Personajes',
    password:   'Personajes',
    server:     'A-PHZ2-AMI-014',
    database:   'PersonajesTP',
    options: {
        trustServerCertificate:     true,
        trustedConnection:          true,
    }
}
export default config