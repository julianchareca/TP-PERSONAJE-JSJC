const config = {
    user:       'Personajes',
    password:   'Personajes',
    server:     'A-PHZ2-CEO-22',
    database:   'PersonajesTP',
    options: {
        trustServerCertificate:     true,
        trustedConnection:          true,
    }
}
export default config