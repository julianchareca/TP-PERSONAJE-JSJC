class Personaje{
    idPersonaje;
    imagen;
    nombre;
    edad;
    peso;
    historia;
}
export default Personaje;