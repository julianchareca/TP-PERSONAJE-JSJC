class PeliculaOSerie{
    id;
    imagen;
    titulo;
    fechaDeCreacion;
    calificacion;
}
export default PeliculaOSerie;