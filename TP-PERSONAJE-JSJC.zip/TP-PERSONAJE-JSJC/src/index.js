import express from "express";
import cors from "cors";
import passport from 'passport';
import { jwtStrategy } from './common/jwt.strategy.js';
import { Authenticate } from "./common/jwt.strategy.js";
import PersonajeService from "./services/personajeService.js";

app.use(cors());
app.use(express.json());
passport.use(jwtStrategy);
app.use(passport.initialize());

app.get('/characters', Authenticate, async (req, res) => {
    const Personajes = await PersonajeService.Get();
    res.status(200).json(Personajes)
})