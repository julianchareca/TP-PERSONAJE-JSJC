import express from "express";
import cors from "cors";
import passport from 'passport';
import jwt from "jsonwebtoken";
import "dotenv/config";
import { jwtStrategy } from './common/jwt.strategy.js';
import { Authenticate } from "./common/jwt.strategy.js";
import PersonajeService from "./services/personajeService.js";
import Personaje from "./models/Personaje.js";

/*
http://localhost:3000/

Beraer Token

{
    "nombre": "Ejemplo",
    "libreGluten": "true",
    "importe": "777",
    "descripcion": "Esta es una prueba para ver si funciona correctamente nuestro codigo creado por J.S & J.C"
}
*/

const getRandomString = () => {
    var result = "";
    var characters =
      "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
    var charactersLength = characters.length;
    for (var i = 0; i < 18; i++) {
      result += characters.charAt(Math.floor(Math.random() * charactersLength));
    }
    return result;
  };
  
  const getSignedToken = () => {
    const userId = getRandomString();
    const userMail = `${userId}@example.com`;
    const token = jwt.sign(
      {
        payload: "custom payload",
        userEmail: userMail,
      },
      process.env.AUTH_HS256_KEY,
      {
        issuer: "http://personaje.js&jc/",
        subject: userId,
        audience: ["http://localhost/"],
        expiresIn: 60 * 24 * 24,
      }
    );
    return token;
  };
console.log(getSignedToken());
const port = 3000
const app = express();

app.use(cors());
app.use(express.json());
passport.use(jwtStrategy);
app.use(passport.initialize());

app.get('/auth/login', async (req, res) => {
  const token = getSignedToken();
  return res.status(200).json(token);
});

app.get('/characters', Authenticate, async (req, res) => {
    const imagen = req.query.imagen
    const nombre = req.query.nombre
    const id = req.query.idPersonaje
    const Personajes = await PersonajeService.Get(imagen, nombre, id);
    res.status(200).json(Personajes)
});

app.post('/characters/create/', Authenticate, async (req, res)=> {
  const personaje = new Personaje()
  personaje.nombre = req.body.nombre
  personaje.imagen = req.body.imagen
  personaje.edad = req.body.edad
  personaje.peso = req.body.peso
  personaje.historia = req.body.historia
  await PersonajeService.Create(personaje)
  res.status(201).json(personaje)
});

app.put('/characters/update/', Authenticate, async (req, res) => {
  const id = req.params.id
  const personaje2 = new Personaje()
  personaje.nombre = req.body.nombre
  personaje.imagen = req.body.imagen
  personaje.edad = req.body.edad
  personaje.peso = req.body.peso
  personaje.historia = req.body.historia
  await PersonajeService.Update(personaje2, id)
  res.status(200).json(personaje2)
});
app.delete('/characters/delete/', Authenticate, async (req, res) => {
  const id = req.params.id
  await pizzaService.Delete(id);
  res.status(200).json(Pizza)
});



app.listen(port, () => {
    console.log(`Se esta usando el puerto: ${port}`)
});