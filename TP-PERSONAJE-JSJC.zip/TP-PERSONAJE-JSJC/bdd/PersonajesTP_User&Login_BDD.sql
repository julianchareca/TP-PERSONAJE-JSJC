USE [master]
GO
CREATE LOGIN [Personajes] WITH PASSWORD=N'Pizzas', DEFAULT_DATABASE=[PersonajesTp], CHECK_EXPIRATION=OFF, CHECK_POLICY=OFF
GO

USE [PersonajesTp]
GO
CREATE USER [Personajes] FOR LOGIN [Personajes]
GO
USE [PersonajesTp]
GO
ALTER ROLE [db_owner] ADD MEMBER [Personajes]
GO